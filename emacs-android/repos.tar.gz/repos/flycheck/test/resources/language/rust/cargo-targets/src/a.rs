fn foo_a() {}

#[test]
fn test() { let foo_a_test = 0; }
