fn main() {
  let a = 0;
}
