An dummy documentation
===================

Contents:

.. toctree::
   :maxdepth: 2

Really, it's cool_ with :envvar:`FOO`!
