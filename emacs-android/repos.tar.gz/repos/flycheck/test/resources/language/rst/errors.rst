=============
 Hello world
=============

Lorem ipsum.

A title with short underline
====


.. warning::

   Foo
   ===

Let us check ReStructuredText_.

Oh now, this one is too
----

Really, it's cool_!

.. note::

   Bar
   ===
