a <- function(file, b = 2) {cat("Hello World!\\n", file=file)
}
b <- function() {
    "/absolute/path/to/file"
}
b <- function() {
    b
