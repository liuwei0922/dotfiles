bogus

module Haskell.SyntaxError where
