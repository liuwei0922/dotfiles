module Foo (foo) where

foo :: a -> a
foo x = x

