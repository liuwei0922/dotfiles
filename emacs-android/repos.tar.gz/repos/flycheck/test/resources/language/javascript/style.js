/** Tab indentation */

(function() {
	var foo = ["Hello world"];
}());
