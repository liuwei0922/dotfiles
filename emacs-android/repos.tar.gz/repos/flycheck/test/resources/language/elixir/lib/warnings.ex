defmodule Warnings do
  @moduledoc "Removes info warning"

  def give_warnings do
    if true && true do
    end

    if length(list) == 0 do
    end
  end
end
