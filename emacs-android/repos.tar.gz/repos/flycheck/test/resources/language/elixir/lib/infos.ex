defmodule Infos do
  def give_infos() do
    IO.puts "Hello World"
  end
end
