package main

import (
	"b2"
	"fmt"
)

func main() {
	fmt.Println("from b1 I'm calling", b2.Call())
}
